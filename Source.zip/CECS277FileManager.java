package cecs277.file.manager;

public class CECS277FileManager {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        App app = new App();
        app.go();
    }
}